using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MvcTemplate.Views.Categoria
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
