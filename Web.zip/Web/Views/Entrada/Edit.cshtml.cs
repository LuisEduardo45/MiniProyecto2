using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MvcTemplate.Views.Entrada
{
    public class EditModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
