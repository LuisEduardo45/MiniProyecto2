﻿using Microsoft.AspNetCore.Identity;

namespace MvcTemplate.Models
{
    public class ApplicationUser : IdentityUser
    {
        // Puedes añadir propiedades personalizadas aquí
        // Ejemplo:
        // public string NombreCompleto { get; set; }
        // public DateTime FechaNacimiento { get; set; }
    }
}